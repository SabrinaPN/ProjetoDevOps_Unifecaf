# Parte Prática – Relatório técnico

## 1. Visão geral da solução

O projeto implementa um MVP de plataforma distribuída para a Loja Veloz com quatro microsserviços: API Gateway, Pedidos, Pagamentos e Estoque. A proposta foi desenhada para demonstrar o fluxo completo do desenvolvimento local até uma entrega automatizada para Kubernetes, contemplando padronização, segurança básica, estratégia de deploy e capacidade de observação operacional.

## 2. Ambiente local com Docker Compose

O arquivo `docker-compose.yml` sobe todos os serviços com um único comando (`docker compose up --build`). Foram definidos rede interna dedicada, volume persistente para o serviço de pedidos e variáveis de ambiente para desacoplar a configuração do código.

## 3. Conteinerização e versionamento

Cada serviço possui um `Dockerfile` próprio usando build em duas etapas. A imagem final utiliza `python:3.12-slim`, instala apenas dependências necessárias, executa com usuário não-root e expõe somente a porta do serviço. As tags de imagem usam convenção semântica (`1.0.0`) e podem ser conectadas ao SHA do commit em evolução futura.

## 4. Kubernetes – produção mínima

Os manifests na pasta `k8s/base` implementam namespace dedicado, ConfigMap, Secret, Deployments, Services, HPA e NetworkPolicy. Os Deployments usam estratégia RollingUpdate com `maxUnavailable: 0`, readiness e liveness probes e requests/limits de CPU e memória.

## 5. CI/CD

O workflow em `.github/workflows/ci-cd.yml` executa testes em matriz por serviço, build local das imagens via Compose, geração de artifact com manifests e etapas preparadas para publicação e deploy. O pipeline foi organizado para separar teste, build, publicação e deploy, com uso de environment `production` para gates futuros.

## 6. Observabilidade e resiliência

A proposta considera observabilidade em três sinais: métricas (latência, taxa de erro, uso de CPU e memória, throughput), logs estruturados em stdout e tracing distribuído baseado em OpenTelemetry. Para redução de risco, o baseline escolhido foi Rolling Update. Como evolução, o projeto recomenda canary deploy com service mesh em serviços críticos.

## 7. Escalabilidade

Foi adotado HPA no API Gateway com mínimo de 2 e máximo de 10 réplicas, usando CPU como gatilho inicial. A justificativa é que o principal requisito do desafio é absorver picos de tráfego. O VPA foi mantido como possibilidade futura para ajustes finos de requests e limits.

## 8. IaC com Terraform

A pasta `terraform/` contém um esqueleto inicial de infraestrutura como código com provider Kubernetes, variáveis, output e espaço para modularização. A ideia é evoluir para provisionamento de namespace, observabilidade, ingress e componentes de segurança de forma reproduzível.

## 9. Conclusão

A solução entrega um projeto-base completo para demonstração acadêmica e MVP técnico. Embora simplificado, o pacote cobre os requisitos principais do desafio: ambiente local padronizado, conteinerização, manifests Kubernetes, pipeline CI/CD, estratégia de deploy, autoscaling, configuração desacoplada e base de observabilidade.
