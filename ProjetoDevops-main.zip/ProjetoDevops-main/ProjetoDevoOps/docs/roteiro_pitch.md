# Roteiro do vídeo pitch (até 4 minutos)

1. Problema da Loja Veloz: deploys arriscados, baixa escalabilidade e pouca rastreabilidade.
2. Arquitetura proposta: gateway + pedidos + pagamentos + estoque + banco.
3. Desenvolvimento local com Docker Compose e comando único.
4. Produção com Kubernetes: Deployments, Services, ConfigMaps, Secrets, probes e HPA.
5. CI/CD: testes, build, artifact e preparação para publicação/deploy.
6. Observabilidade: métricas, logs e traces com OpenTelemetry; canary futuro com service mesh.
7. Conclusão: redução de risco, padronização e base para evolução.
